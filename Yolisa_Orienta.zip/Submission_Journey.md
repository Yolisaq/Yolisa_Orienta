# Hackathon Submission — Build Journey (Brief)

**URL (prototype):** After deployment via GitHub Pages, the app will be live at your chosen URL, e.g. `https://<username>.github.io/orienta/`.

## Approach
- Designed a **single‑file** mobile‑first web app to minimize setup and ensure instant deployability.
- Implemented **orientation routing**: 0°→Alarm, 90°→Stopwatch, 180°→Timer, 270°→Weather. Used `screen.orientation`, `window.orientation` (iOS), with a resize fallback.
- Picked **Open‑Meteo** for weather (free, no API key) + **Geolocation API**; Johannesburg fallback when permission is denied.
- Built **touch‑friendly** UI with clear typography, large hit targets, and subtle transitions for mode changes.
- Added **vibration** and a **data‑URI beep** for feedback that works under mobile autoplay constraints.

## AI Tools Used
- **ChatGPT (GPT‑5 Thinking)** to draft the initial architecture, write the single‑file code, polish UI wording, and craft documentation.

## Prompting Technique
- Used **instruction‑first prompting** with explicit acceptance criteria (APIs, UX, edge cases), followed by **iterative refinement** (UI polish, resilience). See `prompts_used.md` for both successful and failed prompts.

## Screenshots (suggested to add)
- Portrait (Alarm), Landscape→ (Stopwatch), Portrait↓ (Timer), Landscape← (Weather) — captured on a mobile device or Chrome DevTools.

## How to Review
1. Open the URL on a phone; rotate through the four modes.
2. Test weather with Location allowed, then with **Use JHB** fallback.
3. Verify alarm, stopwatch, and timer interactions.

## Next Steps / Nice‑to‑haves
- Persistent storage of alarms and last timer value with `localStorage`.
- Add PWA manifest + service worker for offline installability.
- Optional theming (light mode) and haptics tuning per platform.
