# AI Prompting Log

## Problem statement (given)
Build a one‑page, mobile‑friendly web app that detects orientation and shows:
- Portrait ↑: Alarm Clock
- Landscape →: Stopwatch
- Portrait ↓: Timer
- Landscape ←: Weather of the Day (free weather API)
All in the browser, Android/iOS compatible.

## Prompts that worked
1. **Systematic build prompt**
"""
Create a single‑file HTML app (no frameworks) with mobile‑first CSS and vanilla JS that:
• Detects orientation via screen.orientation, window.orientation (iOS), and resize fallback.
• Maps 0→Alarm, 90→Stopwatch, 180→Timer, 270→Weather.
• Weather: use Open‑Meteo API with geolocation and Johannesburg fallback; show emoji, summary, current temp, today’s high/low.
• Alarm: live digital clock HH:MM:SS; set/clear; snooze 5m; play short beep (data URI) + vibration.
• Stopwatch: start/pause/resume/reset; render every frame.
• Timer: inputs for minutes/seconds; start/pause/reset; beep + vibration on complete.
• Touch‑friendly big buttons; smooth fade transitions between sections; modern dark UI; no external libs.
"""

2. **Polish UI prompt**
"""Tighten the mobile UI with rounded cards, soft shadows, gradient accents, and large typography. Keep it under 600px wide and accessible in high‑contrast dark theme."""

3. **Resilience prompt**
"""Ensure orientation changes are handled on `screen.orientation.change`, `window.orientationchange`, and `resize`. Normalize angles to 0/90/180/270."""

## Prompts that failed (and what changed)
1. **Failed:** "Use DeviceOrientationEvent beta/gamma to decide orientation."
   - **Issue:** Requires motion permissions on iOS and is noisy; not needed.
   - **Fix:** Switched to screen/window orientation APIs with a resize fallback.

2. **Failed:** "Use a free weather API with an API key."
   - **Issue:** Key management conflicts with requirement to run 100% in-browser.
   - **Fix:** Used Open‑Meteo (no key) instead.

3. **Failed:** "Play long MP3 alarm in a loop automatically."
   - **Issue:** Autoplay policies block audio without user gesture.
   - **Fix:** Use short beep (data URI) and vibration; user taps to set alarm which allows audio.
